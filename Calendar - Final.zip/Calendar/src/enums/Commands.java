package enums;

public enum Commands {
    REGISTER,
    ACCOUNTS,
    CREATE,
    EVENTS,
    INVITE,
    RESPONSE,
    EVENT,
    TOPICS,
    HELP,
    EXIT;
}

package enums;

public enum InviteFeedback {
	REMOVE_EVENT,
	CONFLICT_REJECT;
	
}

package exceptions;

public class StaffAccountEventCreationException extends Exception {
    public StaffAccountEventCreationException(){
        super();
    }

}

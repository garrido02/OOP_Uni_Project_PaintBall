package exceptions;

public class AccountAlreadyRepliedException extends Exception {
    public AccountAlreadyRepliedException(){
        super();
    }
}

package exceptions;

public class EventAlreadyExitsException extends Exception {
    public EventAlreadyExitsException(){
        super();
    }

}

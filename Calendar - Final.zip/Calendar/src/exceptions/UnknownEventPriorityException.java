package exceptions;

public class UnknownEventPriorityException extends Exception {
    public UnknownEventPriorityException(){
        super();
    }
}

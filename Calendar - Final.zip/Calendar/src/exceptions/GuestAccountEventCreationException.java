package exceptions;

public class GuestAccountEventCreationException extends Exception {
    public GuestAccountEventCreationException(){
        super();
    }

}

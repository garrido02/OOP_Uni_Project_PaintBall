package exceptions;

public class DuplicateAccountException extends Exception {
    public DuplicateAccountException (){
        super();
    }
}

package exceptions;

public class NoAccountsException extends Exception {
    public NoAccountsException(){
        super();
    }

}

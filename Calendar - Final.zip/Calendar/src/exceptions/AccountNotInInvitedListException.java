package exceptions;

public class AccountNotInInvitedListException extends Exception {
    public AccountNotInInvitedListException(){
        super();
    }
}

/**
 * @author Francisco Correia & Sérgio Garrido
 */


import java.util.Scanner;
import java.util.StringTokenizer;

import PaintBall.*;
import DataStructures.*;


public class Main {
	
	//User commands
    private static final String QUIT = "QUIT";
    private static final String HELP = "HELP";
    private static final String GAME = "GAME";
    private static final String MOVE = "MOVE";
    private static final String ATTACK = "ATTACK";
    private static final String CREATE = "CREATE";
    private static final String STATUS = "STATUS";
    private static final String MAP = "MAP";
    private static final String BUNKERS = "BUNKERS";
    private static final String PLAYERS = "PLAYERS";
    
    //Commands description
    private static final String MOVE_DSC = "move - Move a player";
    private static final String CREATE_DSC = "create - Create a player in a bunker";
    private static final String ATTACK_DSC = "attack - Attack with all players of the current team";
    private static final String STATUS_DSC = "status - Show the current state of the game";
    private static final String MAP_DSC = "map - Show the map of the current team";
    private static final String BUNKERS_DSC = "bunkers - List the bunkers of the current team, by the order they were seized";
    private static final String PLAYERS_DSC = "players - List the active players of the current team, by the order they were created";
    private static final String QUIT_DSC = "quit - End program execution";
    private static final String HELP_DSC = "help - Show available commands";
    private static final String GAME_DSC = "game - Create a new game";
    
    //Program feedback
    private static final String FATAL_ERROR = "FATAL ERROR: Insufficient number of teams.";
    private static final String TEAM_NOT_CREATED_MSG = "Team not created.";
    private static final String BUNKER_NOT_CREATED_MSG = "Bunker not created.";
    private static final String BYE_MSG = "Bye.";
    private static final String INVALID_COMMAND_MSG = "Invalid command.";
	private static final String NON_EXISTING_BUNKER_MSG = "Non-existent bunker.";
	private static final String NON_EXISTING_PLAYERTYPE_MSG = "Non-existent player type.";
	private static final String ILLEGALLY_BUNKER_MSG = "Bunker illegally invaded.";
	private static final String BUNKER_NO_FREE_MSG = "Bunker not free.";
	private static final String PLAYER_CREATED_MSG = "%s player created in %s\n";
	private static final String INSUFFICIENT_COINS_MSG = "Insufficient coins for recruitment.";
	private static final String PLAYER_POSITION_MSG = "%s player in position (%d, %d)\n";
	private static final String INVALID_POSITION_MSG = "Invalid position.";
	private static final String INVALID_DIRECTION_MSG = "Invalid direction.";
	private static final String INVALID_MOVE_MSG = "Invalid move.";
	private static final String NO_PLAYER_MSG = "No player in that position.";
	private static final String OFF_MAP_MSG = "Trying to move off the map.";
	private static final String POSITION_OCCUPIED_MSG = "Position occupied.";
	private static final String WON_FIGHT_MSG = "Won the fight.";
	private static final String BUNKER_SEIZED_MSG = "Bunker seized.";
	private static final String PLAYER_ELIMINATED_MSG = "Player eliminated.";
	private static final String WON_AND_BUNKER_SEIZED_MSG = "Won the fight and bunker seized.";
	private static final String WINNER_MSG = "Winner is %s.\n";
	private static final String TEAMS_HEADER_MSG = "%d teams:\n";
	private static final String PLAYERS_HEADER_MSG = "%d players:\n";
	private static final String BUNKERS_HEADER_MSG = "%d bunkers:\n";
	private static final String WITHOUT_PLAYERS_MSG = "Without players.";
	private static final String BUNKER_POSITION_MSG = "%s with %d coins in position (%d, %d)\n";
	private static final String WITHOUT_BUNKERS_MSG = "Without bunkers.";
	private static final String MAP_SIZE_MSG = "%d %d\n";
	private static final String ALL_PLAYERS_ELIMINATED_MSG = "All players eliminated.";
	
	//Offset of the map position
	private static final int MAP_OFFSET = 1;


    public static void main(String[] args) {
        startApp();
    }

    /**
       Starts the paintball app. Allows the interpretation of multiple commands. The list of available commands depends on
     whether a game is running or not.
     */
    private static void startApp() {
        Scanner in = new Scanner(System.in);
        Game game = new GameClass();
        String command;
        do {
            if (!game.getStatus()) {
                System.out.print("> ");
                command = in.next().toUpperCase();
                switch (command) {
                    case GAME -> processGame(in,game);
                    case HELP -> processHelp(game);
                    case QUIT -> processQuit();
                    default -> processInvalid(in);
                }
            } else {
                System.out.printf("%s> ", game.getCurrentTeam());
                command = in.next().toUpperCase();
                switch(command){
                    case GAME -> processGame(in,game);
                    case MOVE -> processMove(game, in);
                    case CREATE -> processCreate(in,game);
                    case ATTACK-> processAttack(game);
                    case STATUS -> processStatus(game);
                    case MAP -> processMap(game);
                    case BUNKERS -> processBunker(game);
                    case PLAYERS -> processPlayers(game);
                    case HELP -> processHelp(game);
                    case QUIT -> processQuit();
                    default -> processInvalid(in);
                }
            }
        } while (!command.equals(QUIT)) ;
        in.close();
    }

    /**
     * Lists all the available commands depending on whether a game is running or not.
     * @param game Object game which allows access to all game functionalities
     */
    private static void processHelp(Game game){
        if (game.getStatus()){
            System.out.println(GAME_DSC);
            System.out.println(MOVE_DSC);
            System.out.println(CREATE_DSC);
            System.out.println(ATTACK_DSC);
            System.out.println(STATUS_DSC);
            System.out.println(MAP_DSC);
            System.out.println(BUNKERS_DSC);
            System.out.println(PLAYERS_DSC);
            System.out.println(HELP_DSC);
            System.out.println(QUIT_DSC);
        } else {
            System.out.println(GAME_DSC);
            System.out.println(HELP_DSC);
            System.out.println(QUIT_DSC);
        }
    }

    /**
     * Moves a player of the current team.
     * @param game Object game which allows access to all game functionalities
     * @param in Scanner, allowing to access user input
     */
    private static void processMove(Game game, Scanner in) {
        int x = in.nextInt() - MAP_OFFSET;
        int y = in.nextInt() - MAP_OFFSET;
        String nextLine = in.nextLine().toUpperCase().trim();
        Iterator<Move> ite = game.move(x, y, nextLine);
        while(ite.hasNext()){
            Move move = ite.next();
            switch(move.getOutput()){
                case SUCCESS -> System.out.printf(PLAYER_POSITION_MSG, move.playerType(), move.getX()+MAP_OFFSET, move.getY()+MAP_OFFSET);
                case INVALID_POSITION -> System.out.println(INVALID_POSITION_MSG);
                case INVALID_DIRECTION -> System.out.println(INVALID_DIRECTION_MSG);
                case INVALID_MOVE -> System.out.println(INVALID_MOVE_MSG);
                case NO_PLAYER -> System.out.println(NO_PLAYER_MSG);
                case OFF_MAP -> System.out.println(OFF_MAP_MSG);
                case CANNOT_MOVE -> System.out.println(POSITION_OCCUPIED_MSG);
                case WON_FIGHT -> writeBattleOutput(move, WON_FIGHT_MSG);
                case BUNKER_SEIZED -> writeBattleOutput(move, BUNKER_SEIZED_MSG);
                case PLAYER_ELIMINATED -> System.out.println(PLAYER_ELIMINATED_MSG);
                case WON_FIGHT_AND_BUNKER_SEIZED -> writeBattleOutput(move, WON_AND_BUNKER_SEIZED_MSG);
            }
        }
        if (game.isGameOver()){
            System.out.printf(WINNER_MSG, game.getWinner());
        }else
        	game.nextTurn();
    }
    
    /**
     * Writes the feedback of a battle after a movement
     * @param move Object move which allows access to a movement information
     * @param message String with the message output
     */
    private static void writeBattleOutput(Move move, String message) {
    	System.out.println(message);
        System.out.printf(PLAYER_POSITION_MSG, move.playerType(), move.getX()+MAP_OFFSET, move.getY()+MAP_OFFSET);
    }

    /**
     * Creates a player for the current team inside a specified bunker owned by that team.
     * @param in Scanner, allowing to access user input
     * @param game Object game which allows access to all game functionalities
     */
    private static void processCreate(Scanner in, Game game){
    	String type = in.next().toUpperCase();
    	String bunker = in.nextLine().trim();
    	
    	if(!game.isExistingType(type))
    		System.out.println(NON_EXISTING_PLAYERTYPE_MSG);
    	else if(!game.hasBunker(bunker)) 
    		System.out.println(NON_EXISTING_BUNKER_MSG);
    	else if(!game.isBunkerFromCurrentTeam(bunker)) 
    		System.out.println(ILLEGALLY_BUNKER_MSG);	
    	else if(!game.isBunkerFree(bunker)) 
    		System.out.println(BUNKER_NO_FREE_MSG);
    	else if(!game.addPlayer(type, bunker))
    		System.out.println(INSUFFICIENT_COINS_MSG);
    	else 
    		System.out.printf(PLAYER_CREATED_MSG,type.toLowerCase(),bunker);
    	
    	game.nextTurn();
    	
    }

    /**
     * Processes the attack of all current team players.
     * @param game Object game which allows access to all game functionalities
     */
    private static void processAttack(Game game){
        if (game.attack()){
            processMap(game);
            game.nextTurn();
        } else {
            System.out.println(ALL_PLAYERS_ELIMINATED_MSG);
        }
        if (game.isGameOver()){
            System.out.printf(WINNER_MSG, game.getWinner());
        }
    }

    /**
     * Processes the current game status, listing information such as map size, number of bunkers and their name and which team owns that bunker.
     * @param game Object game which allows access to all game functionalities
     */
    private static void processStatus(Game game){
        System.out.printf(MAP_SIZE_MSG, game.getCols(), game.getRows());
        System.out.printf(BUNKERS_HEADER_MSG, game.getBunkersNr());
        Iterator<Bunker> bunkerIte = game.bunkerIterator();
        while (bunkerIte.hasNext()){
            Bunker b = bunkerIte.next();
            System.out.printf("%s (%s)\n", b.getName(), b.getTeamName());
        }
        
        System.out.printf(TEAMS_HEADER_MSG, game.activeTeamsNr());
        Iterator<Team> teamsIte = game.activeTeamsIterator();
        int i = 0;
        while (teamsIte.hasNext()){
            Team t = teamsIte.next();
            i++;
            if(i < game.activeTeamsNr())
            	System.out.printf("%s; ", t.getName());
            else
            	System.out.printf("%s", t.getName());
        }
        System.out.println();
    }

    /**
     * Lists the current map of the game, with all current team's bunkers and players.
     * @param game Object game which allows access to all game functionalities
     */
    private static void processMap(Game game){
    	Iterator<MapElement> mapIte = game.mapIterator();
    	System.out.printf(MAP_SIZE_MSG, game.getCols(), game.getRows());
    	System.out.print("**");
    	for (int i = 1; i < game.getCols(); i++)
    		System.out.printf("%d ",i);
    	System.out.println(game.getCols());
    	for (int rows = 0; rows < game.getRows(); rows++) {
    		System.out.printf("%d",rows+1);
    		for (int cols = 0; cols < game.getCols(); cols++) {
    			System.out.printf(" %s",mapIte.next().getChar());
    		}
    		System.out.println();
    	}
    }

    /**
     * Lists the information of all the current team's bunkers.
     * @param game Object game which allows access to all game functionalities
     */
    private static void processBunker(Game game){
        Iterator<Bunker> ite = game.currentTeamBunkerIterator();
        if (!ite.hasNext()){
            System.out.println(WITHOUT_BUNKERS_MSG);
        } else {
            System.out.printf(BUNKERS_HEADER_MSG, game.getCurrentTeamBunkerNumber());
        }
        while (ite.hasNext()){
                Bunker b = ite.next();
            System.out.printf(BUNKER_POSITION_MSG, b.getName(), b.getTreasury(), b.getX()+MAP_OFFSET, b.getY()+MAP_OFFSET);
        }
    }

    /**
     * Lists the information of all the current team's players.
     * @param game Object game which allows access to all game functionalities
     */
    private static void processPlayers(Game game){
    	if(game.getCurrentTeamPlayersNumber() == 0) {
    		System.out.println(WITHOUT_PLAYERS_MSG); 
    	}else {
    		System.out.printf(PLAYERS_HEADER_MSG, game.getCurrentTeamPlayersNumber());
    		Iterator<Player> playerIte = game.playerIterator();
    		while (playerIte.hasNext()){
    			Player p = playerIte.next();
    			System.out.printf(PLAYER_POSITION_MSG, p.getType(), p.getX()+MAP_OFFSET, p.getY()+MAP_OFFSET);
    		}
    	}
    }

    /**
     * Processes all the new game information, creating a new game.
     * @param in Scanner, allowing to access user input
     * @param game Object game which allows access to all game functionalities
     */
    private static void processGame(Scanner in, Game game){
        int width = in.nextInt();
        int height = in.nextInt();
        int teamsNr = in.nextInt();
        int bunkersNr = in.nextInt();
        in.nextLine();

        game.initGame(width, height, teamsNr, bunkersNr);

        readBunkerData(game, in, bunkersNr);
        readTeamData(game, in, teamsNr);
    }

    /**
     * Reads the user's input for all the information regarding the bunkers to be created after validation.
     * @param game Object game which allows access to all game functionalities
     * @param in Scanner, allowing to access user input
     * @param bunkersNr The number of bunkers to be created
     */
    private static void readBunkerData(Game game, Scanner in, int bunkersNr){
        System.out.printf(BUNKERS_HEADER_MSG, bunkersNr);

        for (int i = 0; i < bunkersNr; i++){
            int xCoord = in.nextInt();
            int yCoord = in.nextInt();
            int treasury = in.nextInt();
            String bunkerName = in.nextLine().trim();

            if (game.isValidPosition(xCoord - MAP_OFFSET, yCoord - MAP_OFFSET) && treasury > 0 && !game.hasBunker(bunkerName)){
                game.addBunker(xCoord - MAP_OFFSET, yCoord - MAP_OFFSET, bunkerName, treasury);
            } else {
                System.out.println(BUNKER_NOT_CREATED_MSG);
            }
        }
    }

    /**
     * Reads the user's input for all the information regarding the teams to be created after validation.
     * @param game Object game which allows access to all game functionalities
     * @param in Scanner, allowing to access user input
     * @param teamsNr The number of bunkers to be created
     */
    private static void readTeamData(Game game, Scanner in, int teamsNr){
        System.out.printf(TEAMS_HEADER_MSG, teamsNr);
        for (int i = 0; i < teamsNr; i++){
            String teamName = in.next();
            String bunkerName = in.nextLine().trim();

            if (!game.hasTeam(teamName) && game.hasBunker(bunkerName) && game.isAbandonedBunker(bunkerName)){
                game.addTeam(teamName, bunkerName);
            } else {
                System.out.println(TEAM_NOT_CREATED_MSG);
            }
        }
        if(!game.hasEnoughTeams()) {
        	System.out.println(FATAL_ERROR);
            game.cancelGame();
        }
    }

    /**
     * Quits the application.
     */
    private static void processQuit(){
        System.out.println(BYE_MSG);
    }

    /**
     * Warns the user of an invalid command usage.
     * @param in Scanner, allowing to access user input
     */
    private static void processInvalid(Scanner in){
    	in.nextLine();
        System.out.println(INVALID_COMMAND_MSG);
    }
}

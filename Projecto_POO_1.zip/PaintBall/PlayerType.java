/**
 * @author Francisco Correia & Sérgio Garrido
 */

package PaintBall;

/**
 * Player type enum responsible to enumerate all available types of player.
 */
public enum PlayerType {
	RED, GREEN, BLUE
}

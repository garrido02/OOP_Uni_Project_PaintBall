/**
 * @author Francisco Correia & Sérgio Garrido
 */

package PaintBall;
import DataStructures.Iterator;

/**
 * The class MapElementIterator that allows to iterate the map filtered by a team.
 */
public class MapElementIterator implements Iterator<MapElement>{
	
	/**
	 * The constant that represents the number zero.
	 */
	private static final int ZERO = 0;
	
	/**
	 * The matrix of MapElement's to iteratre.
	 */
	private MapElement[][] elems;
	
	/**
	 * The MapElement to replace when there is a MapElement of other team.
	 */
	private MapElement empty;
	
    /**
     * Index of the current element
     */
    private int current;
    
    /**
     * Row of the current element 
     */
    private int currentRow;
    
    /**
     * Column of the current element 
     */
    private int currentCol;
    
    /**
     * Number of rows in the matrix
     */
    private int rows;
    
    /**
     * Number of columns in the matrix
     */
    private int cols;
    
    /**
     * Number of elements in the array
     */
    private int size;
    
    /**
     * The object team to filter 
     */
    private Team team;

    /**
     * Constructor.
     * @param elems the matrix of elements to iterate over
     * @param team the team to filter the map
     * @param empty the default element to replace
     */
    public MapElementIterator(MapElement[][] elems, Team team, MapElement empty){
        this.elems = elems;
        this.rows = elems[ZERO].length;
        this.cols = elems.length;
        this.size = rows*cols;
        this.team = team;    
        this.empty = empty;
        init();
        
    }
	
    @Override
    public boolean hasNext() {
        return current < size ;
    }
    
	/**
	 * Initiate all indexes to zero.
	 */
    private void init() {
    	this.current = ZERO;
        this.currentRow = ZERO;
        this.currentCol = ZERO;
    }
    
    /**
     * Checks if there are more rows of elements in the collection to iterate over.
     * @return <code>true</code> if there are more rows, <code>false</code> otherwise
     */
    private boolean hasNextRow() {
    	return currentRow < rows;
    }

    @Override
    public MapElement next(){
    	MapElement m = elems[currentCol++][currentRow];
    	if(!team.equals(m.getTeam()))
    		m = empty;
    	nextRow();
    	//current++;
        return m;
    }

    /**
     * Changes the indexes in case there is a next row to iterate.
     */
    private void nextRow(){
    	if(currentCol == this.cols && hasNextRow()) {
    		currentRow++;
        	currentCol = 0;
    	}	
    }
}

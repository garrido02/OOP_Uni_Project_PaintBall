/**
 * @author Francisco Correia & Sérgio Garrido
 */

package PaintBall;
import DataStructures.Array;
import DataStructures.ArrayClass;

/**
 * Class RedPlayer which extends the PlayerAbstract Class.
 */
public class RedPlayerClass extends PlayerAbstract {
	
	/**
	 * The type of player this class represents.
	 */
	public static final String TYPE = "RED";
	
	/**
	 * Default number of this player type possible moves.
	 */
	static final int MAX_MOVES = 3;
	
	/**
	 * Default cost of this player type.
	 */
	private static final int COST = 4;
	
	/**
	 * Constructor
	 * @param x the horizontal position
	 * @param y the vertical position
	 * @param team the team to which the player belongs to
	 */
	public RedPlayerClass(int x, int y, Team team) {
		super(x, y, team);
		this.cost = COST;
		this.type = TYPE;
		this.possibleMoves = MAX_MOVES;
	}

	@Override
	public Array<Coords> attackPattern(int rows, int cols) {
		Array<Coords> pattern = new ArrayClass<>();
		for (int j = getY(); j < rows; j++){
			for (int i = getX(); i < cols; i++){
				if (!(i == getX() && j == getY())){
					pattern.insertLast(new CoordsClass(i, j));
				}
			}
		}
		return pattern;
	}
}

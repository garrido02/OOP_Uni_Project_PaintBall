/**
 * @author Francisco Correia & Sérgio Garrido
 */

package PaintBall;

/**
 * Class PlayerAbstract which implements the Player and MapElement interfaces.
 */
abstract class PlayerAbstract implements Player, MapElement {

	/**
	 * The symbol of a player on the map.
	 */
	private static final char SYMBOL = 'P';
	
	/**
	 * A Team object representing the team to which the player belongs to.
	 */
	private Team team;
	
	/**
	 * A Coords object representing the coordinates of the player.
	 */
	private Coords coords;
	
	/**
	 * The number of possible moves.
	 */
	protected int possibleMoves;
	
	/**
	 * The creation cost of the player.
	 */
	protected int cost;
	
	/**
	 * The type of the player.
	 */
	protected String type;
	
	/**
	 * The alive status of the player.
	 */
	protected boolean isAlive;

	/**
	 * Constructor.
	 * @param x the horizontal position
	 * @param y the vertical position
	 * @param team a Team object representing the team to which the player belongs to.
	 */
	protected PlayerAbstract(int x, int y, Team team) {
		coords = new CoordsClass(x,y);
		this.team = team;
		this.isAlive = true;
	}
	
	@Override
	public int getPossibleMoves() {
		return possibleMoves;
	}
	
	@Override
	public int getX() {
		return coords.getX();
	}
	
	@Override
	public int getY() {
		return coords.getY();
	}
	
	@Override
	public Team getTeam() {
		return team;
	}
	
	@Override
	public int cost() {
		return cost;
	}
	
	@Override
	public char getChar() {
		return SYMBOL;
	}
	
	@Override
	public String getType() {
		return type.toLowerCase();
	}
	
	/**
	 * Updates the position of the player.
	 * @param dir the direction of the movement
	 */
	private void updatePosition(String dir){
		coords.calculateMove(dir);

	}

	@Override
	public Move move(String dir) {
		updatePosition(dir);
		return new MoveClass(this, MoveOutput.SUCCESS);
	}

	@Override
	public boolean isAlive() {
		return isAlive;
	}

	@Override
	public void eliminate() {
		isAlive = false;
	}
	
	@Override
	public boolean attack(Player other) {
		if(Game.attackingPlayerWins(this, other)) {
			other.eliminate();
		}else
			this.eliminate();
		return isAlive;
	}
}

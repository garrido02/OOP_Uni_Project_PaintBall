/**
 * @author Francisco Correia & Sérgio Garrido
 */


package PaintBall;


/**
 * Class Move responsible for implementing the Move interface.
 */
public class MoveClass implements Move{

    /**
     * A Player object which represents the player who is moving.
     */
    private Player player;

    /**
     * The movement output message.
     */
    private MoveOutput output;

    /**
     * The new horizontal position after moving.
     */
    private int newX;

    /**
     * The new vertical position after moving.
     */
    private int newY;


    /**
     * Constructor for sucessful movements.
     * @param player the player who is moving
     * @param output the output message of the movement
     */
    public MoveClass(Player player, MoveOutput output){
        this.player = player;
        this.output = output;
        this.newX = player.getX();
        this.newY = player.getY();
    }

    /**
     * Constructor for insucessful movements.
     * @param output the output message of the movement
     */
    public MoveClass(MoveOutput output){
        this.output = output;
    }

    @Override
    public int getX() {
        return newX;
    }

    @Override
    public int getY() {
        return newY;
    }

    @Override
    public MoveOutput getOutput() {
        return output;
    }

    @Override
    public Player getPlayer() {
        return player;
    }

    @Override
    public String playerType() {
        return player.getType();
    }
}

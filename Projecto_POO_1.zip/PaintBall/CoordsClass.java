/**
 * @author Francisco Correia & Sérgio Garrido
 */

package PaintBall;

/**
 * Coords class responsible for implementing the Coords interface.
 */
public class CoordsClass implements Coords{
	
	/**
	 * Offset when the coordinate must increase.
	 */
	private static final int OFFSET_POSITIVE = 1;
	
	/**
	 * Offset when the coordinate must decrease.
	 */
	private static final int OFFSET_NEGATIVE = -1;
	
	/**
	 * Offset when the coordinate must not change.
	 */
	private static final int NO_OFFSET = 0;
	
	/**
	 * The horizontal position.
	 */
    private int x;
    
	/**
	 * The vertical position.
	 */
    private int y;

    /**
     * Constructor
     * @param x the horizontal position
     * @param y the vertical position
     */
    public CoordsClass(int x, int y){
       this.x = x;
       this.y = y;
    }

    @Override
    public int getX() {
        return x;
    }

    @Override
    public int getY() {
        return y;
    }
    
    @Override
    public void calculateMove(String dir) {
    	switch(Directions.valueOf(dir)){
            case NORTH -> 
            	applyOffset(NO_OFFSET,OFFSET_NEGATIVE);
            case SOUTH -> 
            	applyOffset(NO_OFFSET,OFFSET_POSITIVE);      	
            case EAST -> 
            	applyOffset(OFFSET_POSITIVE,NO_OFFSET);
            case WEST -> 
            	applyOffset(OFFSET_NEGATIVE,NO_OFFSET);
        };
    }
    
	/**
	 * Adds the offsets based to change the coordinates accordingly.
	 * @param offsetX the horizontal offset to be added to x coordinate
	 * @param offsetY the vertical offset to be added to y coordinate
	 */
    private void applyOffset(int offsetX,  int offsetY) {
    	this.x += offsetX; 
    	this.y += offsetY;
    }
    
}

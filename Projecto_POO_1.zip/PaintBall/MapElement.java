/**
 * @author Francisco Correia & Sérgio Garrido
 */

package PaintBall;

/**
 * Interface MapElement responsible for creating all the elements that form the Map.
 */
public interface MapElement {
	
    /**
     * Returns the symbol of the element in the map.
     * @return the char symbol of the element.
     */
	char getChar();
	
    /**
     * Returns the horizontal position.
     * @return the horizontal position
     */
	int getX();
	
    /**
     * Returns the vertical position.
     * @return the vertical position
     */
	int getY();
	
    /**
     * Returns the team of the Map Element. Can be null if empty element.
     * @return a Team object representing the team of the element.
     */
	Team getTeam();
}

/**
 * @author Francisco Correia & Sérgio Garrido
 */

package PaintBall;

/**
 * Class EmptyElement which implements the MapElement interface.
 */
public class EmptyElementClass implements MapElement {

	/**
	 * The symbol of an empty space on the map.
	 */
	private static final char SYMBOL = '.';
	
	/**
	 * The default team of an empty space that is always null.
	 */
    private static final Team TEAM = null;
    
	/**
	 * A Coords object representing the coordinates of the element.
	 */
    private Coords coords;
	
	/**
	 * Constructor
	 */
    public EmptyElementClass() {
    	coords = new CoordsClass(0,0);
    }
	
	@Override
	public char getChar() {
		return SYMBOL;
	}

	@Override
	public int getX() {
		return coords.getX();
	}

	@Override
	public int getY() {
		return coords.getY();
	}

	@Override
	public Team getTeam() {
		return TEAM;
	}

}

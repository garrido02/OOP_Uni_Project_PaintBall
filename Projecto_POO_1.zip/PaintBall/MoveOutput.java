/**
 * @author Francisco Correia & Sérgio Garrido
 */

package PaintBall;

/**
 * MoveOutput enum responsible to enumerate all possible outputs after a player movement.
 */
public enum MoveOutput {
    INVALID_POSITION, INVALID_DIRECTION, NO_PLAYER, OFF_MAP, BUNKER_SEIZED, WON_FIGHT,
    PLAYER_ELIMINATED, SUCCESS, INVALID_MOVE, CANNOT_MOVE, WON_FIGHT_AND_BUNKER_SEIZED
}


/**
 * @author Francisco Correia & Sérgio Garrido
 */

package PaintBall;

/**
 * Class Bunker responsible for implementing the Bunker and MapElement interfaces.
 */
public class BunkerClass implements Bunker {
	
    /**
     * Team name when a bunker is abandoned.
     */
	private static final String NO_TEAM = "without owner";
	
    /**
     * The symbol of a free bunker on the map.
     */
    private static final char SYMBOL = 'B';
    
    /**
     * The symbol of a occupied bunker on the map.
     */
    private static final char OCCUPIED_SYMBOL = 'O';
    
    /**
     * The name of the bunker.
     */
    private String name;
    
    /**
     * An object of class Player that may be inside the bunker. Can be null if bunker is free.
     */
    private Player player;
    
	/**
	 * A Team object representing the team to which the bunker belongs to. Can be null if bunker is abandoned.
	 */
    private Team team;
    
	/**
	 * A Coords object representing the coordinates of the Bunker.
	 */
    private Coords coords;
    
    /**
     * The ammount of coins the bunker has.
     */
    private int treasury;

    /**
     * Constructor.
     * @param x the horizontal position
     * @param y the vertical position
     * @param name the name of the bunker
     * @param treasury the initial amount of coins of the bunker
     */
    public BunkerClass(int x, int y, String name, int treasury){
        coords = new CoordsClass(x,y);
        this.name = name;
        this.team = null;
        this.treasury = treasury;
    }

    @Override
    public Team getTeam() {
        return this.team;
    }
    
    
    @Override
    public boolean createPlayer(String playerType) {
    	boolean result = switch(PlayerType.valueOf(playerType)) {
			case BLUE -> hasEnoughCoins(new BluePlayerClass(getX(),getY(),team));
			case RED -> hasEnoughCoins(new RedPlayerClass(getX(),getY(),team));
			case GREEN -> hasEnoughCoins(new GreenPlayerClass(getX(),getY(),team));
    	};
    	return result;
    }
    
    /**
     * Checks if the bunker has enough coins to create a player of a specific type.
     * @param player The player to be created
     * @return <code>true</code> if the bunker has enough coins for the creation. Otherwise, <code>false</code>.
     */
    private boolean hasEnoughCoins(Player player) {
    	boolean created = false;
    	if(player != null && this.treasury >= player.cost())
		{
    		this.player = player;
        	team.addPlayer(player);
            this.treasury -= player.cost();
        	created = true;
		};   	
    	return created;
    }

    @Override
    public void playerOut() {
    	player = null;
    }

    @Override
    public void playerIn(Player player){
        this.player = player;
    }

    @Override
    public Player getPlayer() {
        return player;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public boolean isAbandoned() {
        return team == null;
    }

    @Override
    public void changeTeam(Team t) {
        team = t;
    }

    @Override
    public void incrementTreasury() {
        treasury++;
    }

	@Override
	public char getChar() {
		char symbol = OCCUPIED_SYMBOL;		
		if(player == null)
			symbol = SYMBOL;	
		return symbol;
	}

	@Override
	public int getX() {
		return coords.getX();
	}

	@Override
	public int getY() {
		return coords.getY();
	}

	@Override
	public boolean isFree() {
		return player == null;
	}

    @Override
    public int getTreasury() {
        return treasury;
    }

	@Override
	public String getTeamName() {
		String teamName = NO_TEAM;
		if(team != null)
			teamName = team.getName();
		
		return teamName;
	}
}

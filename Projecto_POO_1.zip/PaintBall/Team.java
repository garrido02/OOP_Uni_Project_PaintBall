/**
 * @author Francisco Correia & Sérgio Garrido
 */

package PaintBall;
import DataStructures.Iterator;

/**
 * Interface Team responsible for creating all the Team Class prototypes.
 */
public interface Team {

    /**
     * Returns the name of the team.
     * @return the team's name
     */
	String getName();

    /**
     * Conquers a given bunker.
     * @param bunker a Bunker object representing the bunker to be conquered
     * @pre bunker != null
     */
    void conquerBunker(Bunker bunker);

    /**
     * Checks if the team is active.
     * @return <code>true</code> if the team is active. Otherwise, <code>false</code>.
     */
    boolean isActive();

    /**
     * Changes the team status.
     */
    void changeStatus();

    /**
     * Adds a player to the team.
     * @param player a Player object representing the player to be added to the team
     * @pre player != null
     */
    void addPlayer(Player player);

    /**
     * Removes a player from the team.
     * @param player a Player object representing the player to be removed from the team
     * @pre player != null
     */
    void removePlayer(Player player);

    /**
     * An iterator for all the players on the team.
     * @return an Iterator of players object with information of each player of the team
     */
    Iterator<Player> playerIterator();

    /**
     * An iterator for all the bunkers owned by the team.
     * @return an Iterator of bunkers object with information of each bunker owned by the team
     */
    Iterator<Bunker> bunkerIterator();

    /**
     * Returns the number of bunkers owned by the team.
     * @return the number of bunkers owned by the team
     */
    int numberBunkers();

    /**
     * Returns the number of players on the team.
     * @return the number of players on the team
     */
    int numberPlayer();

    /**
     * Removes a given bunker from the team's ownership.
     * @param bunker a Bunker object representing the bunker to be removed from the team's ownership.
     * @pre bunkers.searchIndexOf(bunker) != -1
     */
    void removeBunker(Bunker bunker);
}

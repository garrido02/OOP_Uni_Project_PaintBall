/**
 * @author Francisco Correia & Sérgio Garrido
 */


package PaintBall;


/**
 * Interface Move responsible for creating all the Move Class prototypes.
 */
public interface Move {

    /**
     * Returns the horizontal position.
     * @return the horizontal position
     */
    int getX();

    /**
     * Returns the vertical position.
     * @return the vertical position
     */
    int getY();

    /**
     * Returns the player type.
     * @return the player type
     */
    String playerType();

    /**
     * Returns the move output of the movement.
     * @return the move output
     */
    MoveOutput getOutput();

    /**
     * Returns the player who moved.
     * @return a Player object representing the player who moved.
     */
    Player getPlayer();
    

}


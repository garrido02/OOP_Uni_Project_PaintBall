/**
 * @author Francisco Correia & Sérgio Garrido
 */

package PaintBall;
import DataStructures.*;
import java.util.Objects;
import DataStructures.Iterator;

/**
 * Class Team responsible for implementing the Team interface.
 */
public class TeamClass implements Team {
   
    /**
     * Default value to return for when an element is not found.
     */
    private static final int NOT_FOUND = -1;
	
	/**
     * The name of the team.
     */
    private String name;

    /**
     * The active status of the team.
     */
    private boolean status;

    /**
     * An array of bunkers.
     */
    private ArrayClass<Bunker> bunkers;

    /**
     * An array of players.
     */
    private ArrayClass<Player> players;

    /**
     * Constructor.
     * @param name the name of the team
     */
    public TeamClass(String name){
        this.name = name;
        status = true;
        bunkers = new ArrayClass<>();
        players = new ArrayClass<>();
    }

    @Override
    public void addPlayer(Player player) {
    	players.insertLast(player);
    }
    
    @Override
    public void removeBunker(Bunker bunker) {
        if(existsBunker(bunker)) {
        	bunkers.removeAt(bunkers.searchIndexOf(bunker));
            isEliminated();
        }
    }
    
    /**
     * Searches if the bunker is in the array of bunkers.
     * @param bunker a Bunker object representing the bunker to be searched
     * @return <code>true</code> if there is the bunker in the array. Otheriwse, <code>false</code>.
     */
    private boolean existsBunker(Bunker bunker) {
    	return bunkers.searchIndexOf(bunker) != NOT_FOUND;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public boolean isActive() {
        return status;
    }

    @Override
    public void changeStatus() {
        status = false;
    }

    @Override
    public void conquerBunker(Bunker bunker) {
        bunkers.insertLast(bunker);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TeamClass teamClass = (TeamClass) o;
        return Objects.equals(name, teamClass.name);
    }
    
    @Override
    public Iterator<Player> playerIterator(){
    	return players.iterator();
    }

    @Override
    public Iterator<Bunker> bunkerIterator() {
        return bunkers.iterator();
    }

    @Override
	public int numberPlayer() {
		return players.size();
	}

    @Override
    public int numberBunkers() {
        return bunkers.size();
    }

    @Override
    public void removePlayer(Player player) {
        players.removeAt(players.searchIndexOf(player));
        isEliminated();
    }

    /**
     * Changes the active status of the team.
     */
    private void isEliminated(){
        if (players.size() == 0 && bunkers.size() == 0){
            status = false;
        }
    }
}
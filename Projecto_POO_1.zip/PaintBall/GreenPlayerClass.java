/**
 * @author Francisco Correia & Sérgio Garrido
 */

package PaintBall;
import DataStructures.Array;
import DataStructures.ArrayClass;

/**
 * Class GreenPlayer which extends the PlayerAbstract Class.
 */
public class GreenPlayerClass extends PlayerAbstract {
	
	/**
	 * The type of player this class represents.
	 */
	public static final String TYPE = "GREEN";
	
	/**
	 * Default number of this player type possible moves.
	 */
	private static final int MAX_MOVES = 1;
	
	/**
	 * Default cost of this player type.
	 */
	private static final int COST = 2;
	
	/**
	 * Multiplier when the coordinates must decrease.
	 */
	private static final int NEGATIVE_MULTIPLIER = -1;
	
	/**
	 * Multiplier when the coordinates must increase.
	 */
	private static final int POSITIVE_MULTIPLIER = 1;
	
	/**
	 * Constructor
	 * @param x the horizontal position
	 * @param y the vertical position
	 * @param team the team to which the player belongs to
	 */
	public GreenPlayerClass(int x, int y, Team team) {
		super(x, y, team);
		this.cost = COST;
		this.type = TYPE;
		this.possibleMoves = MAX_MOVES;
	}

	@Override
	public Array<Coords> attackPattern(int rows, int cols) {
		int x = this.getX();
		int y = this.getY();
 		Array<Coords> pattern = new ArrayClass<>();
		int nrSteps = 1;
		while (x - nrSteps >= 0 || x + nrSteps < cols || y - nrSteps >= 0 || y + nrSteps < rows){
			if (x - nrSteps >= 0 && y - nrSteps >= 0){
				pattern.insertLast(calculateNextPos(x, y, NEGATIVE_MULTIPLIER, NEGATIVE_MULTIPLIER, nrSteps));
			}
			if (x + nrSteps < cols && y - nrSteps >= 0){
				pattern.insertLast(calculateNextPos(x, y, POSITIVE_MULTIPLIER, NEGATIVE_MULTIPLIER, nrSteps));
			}
			if (x - nrSteps >= 0 && y + nrSteps < rows){
				pattern.insertLast(calculateNextPos(x, y, NEGATIVE_MULTIPLIER, POSITIVE_MULTIPLIER, nrSteps));
			}
			if (x + nrSteps < cols && y + nrSteps < rows){
				pattern.insertLast(calculateNextPos(x, y, POSITIVE_MULTIPLIER, POSITIVE_MULTIPLIER, nrSteps));
			}
			nrSteps++;
		}
		return pattern;
	}
	
	/**
	 * Calculates and returns a Coords object with the next coordinates of the attack.
	 * @param x the horizontal position
	 * @param y the vertical position
	 * @param multiplierX the multiplier that indicates if vertical position should move left or right
	 * @param multiplierY the multiplier that indicates if horizontal position should move up or down
	 * @param adder represents how much both coordinates should move
	 * @returns the new coordinates after calculating 
	 */
	private Coords calculateNextPos(int x, int y, int multiplierX, int multiplierY, int adder) {
		int nextPosX = x + (multiplierX*adder);
		int nextPosY = y + (multiplierY*adder);
		return new CoordsClass(nextPosX, nextPosY);
	}
}

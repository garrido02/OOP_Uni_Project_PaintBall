/**
 * @author Francisco Correia & Sérgio Garrido
 */
package PaintBall;

/**
 * Interface Coords responsible for saving specific map coordinates.
 */
public interface Coords {
	
    /**
     * Returns the horizontal position.
     * @return the horizontal position
     */
    int getX();
    
    /**
     * Returns the vertical position.
     * @return the vertical position
     */
    int getY();
    
    /**
     * Calculates the next coordinates of the next move in given direction
     * @param dir the direction to calculate the move
     * @pre: dir != null
     */
	void calculateMove(String dir);
}

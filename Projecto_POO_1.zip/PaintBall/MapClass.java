/**
 * @author Francisco Correia & Sérgio Garrido
 */
package PaintBall;

import DataStructures.Iterator;

/**
 * Class Map which implements the Map interface.
 */
public class MapClass implements Map{
	
	/**
	 * The MapElement object that always represents an empty space on map.
	 */
	private static final MapElement EMPTY = new EmptyElementClass();
	
	/**
	 * The matrix of Map Elements that is the map.
	 */
    private MapElement[][] mapE;
    
	/**
	 * The number of columns in the map.
	 */
    private int cols;
    
	/**
	 * The number of rows in the map.
	 */
    private int rows;
    
    /**
     * Constructor.
     * @param width the number of columns of the map
     * @param height the number of rows of the map
     */
    public MapClass(int width, int height){
        this.cols = width;
        this.rows = height;
        mapE = new MapElement[cols][rows];
        fillMap();
    }

    /**
     * Fills the map with empty cells allowing the game to start anew.
     */
    private void fillMap(){
        for (int i = 0; i < mapE.length; i++){
            for (int j = 0; j < mapE[0].length; j++){
               mapE[i][j] = EMPTY;
            }
        }
    }

    @Override
    public void addElement(MapElement e, int x, int y) {
        mapE[x][y] = e;
    }

    @Override
    public int getHeight() {
        return rows;
    }

    @Override
    public int getWidth() {
        return cols;
    }

    @Override
    public boolean isValidPosition(int x, int y) {
        return isInside(x, y) && isEmpty(x, y);
    }


    @Override
    public Iterator<MapElement> iterator(Team team) {
        return new MapElementIterator(mapE, team, EMPTY);
    }

    /**
     * Checks if a map coordinate (x,y) is an empty cell.
     * @param x the horizontal position
     * @param y the vertical position
     * @return <code>true</code> if the map cell is empty. Otherwise, <code>false</code>.
     */
    private boolean isEmpty(int x, int y){
        return (mapE[x][y] instanceof EmptyElementClass);
    }

    @Override
    public boolean isInside(int a, int b) {
        boolean validRow = b >= 0 && b < this.rows;
        boolean validCol = a >= 0 && a < this.cols;
        return validRow && validCol;
    }

    @Override
    public void removeElement(int x, int y) {
        mapE[x][y] = EMPTY;
    }

    @Override
	public boolean nextCellOccupied(int x, int y, String dir) {
		Coords coords = new CoordsClass(x,y);
		coords.calculateMove(dir);
		MapElement player = getElement(x,y);
		MapElement cell = getElement(coords.getX(),coords.getY());
		return((cell instanceof Player) && player.getTeam().equals(cell.getTeam()));
	}

    @Override
    public MapElement getElement(int x, int y) {
        return mapE[x][y];
    }
}

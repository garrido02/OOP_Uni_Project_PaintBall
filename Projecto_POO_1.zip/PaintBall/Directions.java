/**
 * @author Francisco Correia & Sérgio Garrido
 */

package PaintBall;

/**
 * Direction enum responsible to enumerate all available direction.
 */
public enum Directions {
    NORTH, SOUTH, EAST, WEST
}

/**
 * @author Francisco Correia & Sérgio Garrido
 */


package PaintBall;
import DataStructures.*;
import java.util.StringTokenizer;


/**
 * Class Game which implements Game interface.
 */
public class GameClass implements Game {

    /**
     * Default value to return for when an element is not found.
     */
    private static final int NOT_FOUND = -1;

    /**
     * The minimum amount of teams required to start the game.
     */
    private static final int MINIMUM_TEAMS = 2;

    /**
     * The status of the game. True if the game is running. Otherwise, false.
     */
    private boolean status;

    /**
     * The team who is currently playing
     */
    private Team currentTeam;

    /**
     * The name of the team who won.
     */
    private String winner;

    /**
     * An object of class Map, allowing to acess all the map funcionalities.
     */
    private Map map;

    /**
     * An array of teams.
     */
    private ArrayClass<Team> teams;

    /**
     * An array of bunkers.
     */
    private ArrayClass<Bunker> bunkers;

    /**
     * An array os moves.
     */
    private ArrayClass<Move> lastMovements;

    /**
     * Default constructor for when the game is not running.
     */
    public GameClass(){
        status = false;
    }

    @Override
    public void initGame(int width, int height, int teamsNr, int bunkersNr){
        status = true;
        map = new MapClass(width, height);
        bunkers = new ArrayClass<>(bunkersNr);
        teams = new ArrayClass<>(teamsNr);
    }

    @Override
    public int getBunkersNr() {
        return bunkers.size();
    }

    @Override
    public int activeTeamsNr() {
        int activeTeams = 0;
        Iterator<Team> ite = teams.iterator();
        while (ite.hasNext()){
            activeTeams++;
            ite.next();
        }
        return activeTeams;
    }

    @Override
    public Iterator<Bunker> bunkerIterator() {
        return bunkers.iterator();
    }

    @Override
    public Iterator<Team> activeTeamsIterator() {
        return teams.iterator();
    }

    @Override
    public void cancelGame() {
        status = false;
    }

    @Override
    public int getCols() {
        return map.getWidth();
    }

    @Override
    public int getRows() {
        return map.getHeight();
    }

    @Override
    public boolean getStatus() {
        return status;
    }

    @Override
    public String getCurrentTeam() {
        return currentTeam.getName();
    }

    @Override
    public boolean isValidPosition(int x, int y) {
        return map.isValidPosition(x, y);
    }

    /**
     * Checks if a given position is in bounds.
     * @param x The horizontal position
     * @param y The vertical position
     * @return <code>true</code> if the position is in bounds. Otherwise, <code>false</code>.
     */
    private boolean isInside(int x, int y) {
        return map.isInside(x, y);
    }

    @Override
    public boolean hasBunker(String name) {
    	return findBunkerIdx(name) != NOT_FOUND;
    }
    
    /**
     * Returns the bunker index of the bunker with a given name
     * @param name The name of the bunker
     * @return the index of the bunker
     */
    private int findBunkerIdx(String name){
        int i = 0;
        Iterator<Bunker> ite = bunkers.iterator();
        while (ite.hasNext()){
            if (ite.next().getName().equals(name)){
                return i;
            }
            i++;
        }
        return NOT_FOUND;
    }

    @Override
    public void addBunker(int x, int y, String name, int treasury) {
        Bunker bunker = new BunkerClass (x,y,name,treasury);
        bunkers.insertLast(bunker);
        map.addElement(bunker, x, y);
    }

    @Override
    public void addTeam(String teamName, String bunkerName) {
        Bunker bunker = bunkers.get(findBunkerIdx(bunkerName));
    	Team team = new TeamClass(teamName);
    	if (teams.size() == 0){
             currentTeam = team;
        }
        teams.insertLast(team);
        conquerBunker(team, bunker);
        
    }
    
    /**
     * Conquers a given bunker changing its owner to a given team.
     * @param team The teams who will conquer the bunker
     * @param bunker The bunker who will change owners
     */
    private void conquerBunker(Team team, Bunker bunker) {
    	bunker.changeTeam(team);
        team.conquerBunker(bunker);
    }


    @Override
    public boolean hasTeam(String name) {
        return findTeamIdx(name) != NOT_FOUND;
    }
    
    /**
     * Returns the index of a team with a given name.
     * @param name The name of a given team
     * @return the index of the team
     */
    private int findTeamIdx(String name){
        int i = 0;
        Iterator<Team> ite = teams.iterator();
        while (ite.hasNext()){
            if (ite.next().getName().equals(name)){
                return i;
            }
            i++;
        }
        return NOT_FOUND;
    }

    @Override
    public boolean isAbandonedBunker(String name) {
        return bunkers.get(findBunkerIdx(name)).isAbandoned();
    }

	@Override
	public boolean hasEnoughTeams() {
		return teams.size() >= MINIMUM_TEAMS;
	}
	
	@Override
	public Iterator<MapElement> mapIterator() {
		return map.iterator(currentTeam);
	}

	@Override
	public boolean addPlayer(String playerType, String bunkerName) {
			return bunkers.get(findBunkerIdx(bunkerName)).createPlayer(playerType);
	}
	
	@Override
	public void nextTurn() {
		changeCurrentTeam();
		incrementTreasury();
	}

    /**
     * Changes the current team to the next active team by order of creation.
     */
    private void changeCurrentTeam(){
        int i = findTeamIdx(currentTeam.getName());
        i = (i + 1) % teams.size();
        currentTeam = teams.get(i);        
    }

    /**
     * Increments the amount of coins of each bunker by 1.
     */
    private void incrementTreasury() {
    	Iterator<Bunker> ite = bunkers.iterator();
        while (ite.hasNext()){
            ite.next().incrementTreasury();     
        }
    }
    
    @Override
	public boolean isExistingType(String playerType) {
		boolean exists = true;
		try{
			PlayerType.valueOf(playerType);
		}catch (IllegalArgumentException e) {
			exists = false;
		}
		return exists;
	}

	@Override
	public boolean isBunkerFromCurrentTeam(String name) {
		return currentTeam.equals(bunkers.get(findBunkerIdx(name)).getTeam());
	}

	@Override
	public boolean isBunkerFree(String name) {
		return bunkers.get(findBunkerIdx(name)).isFree();
	}
	
	@Override
	public Iterator<Player> playerIterator(){
		return currentTeam.playerIterator();
	}

    @Override
    public Iterator<Bunker> currentTeamBunkerIterator() {
        return currentTeam.bunkerIterator();
    }

    @Override
    public int getCurrentTeamPlayersNumber() {
		return currentTeam.numberPlayer();
	}

    @Override
    public int getCurrentTeamBunkerNumber() {
        return currentTeam.numberBunkers();
    }

    @Override
    public Iterator<Move> move(int x, int y, String nextLine) {
    	StringTokenizer token = new StringTokenizer(nextLine);
    	int nrMoves = token.countTokens();
    	lastMovements = new ArrayClass<>(nrMoves);

    	if(this.checkGenericMoveConditions(x, y, nrMoves)) {
    		Player player = findPlayer(x, y, currentTeam);
    		do {
    			String dir = token.nextToken();
    			if(this.checkEachMoveConditions(player, dir)) {
    				lastMovements.insertLast(movePlayer(player, dir, player.getX(), player.getY()));
    			}
    		} while (token.hasMoreTokens());
    	}
    	return lastMovements.iterator();
    }
    
    /**
     * Checks if the movement in a certain direction is possible
     * @param player The player who is about to move
     * @param direction The direction the player is about to move
     * @return <code>true</code> if player moved with success. Otherwise, <code>false</code>.
     * @pre checkGenericMoveConditions = true
     */
    private boolean checkEachMoveConditions(Player player, String direction) {
    	boolean result = false;
    	if (!isValidDirection(direction)){
    		lastMovements.insertLast(new MoveClass(MoveOutput.INVALID_DIRECTION));
    	} else if (!isMovementPossible(direction, player.getX(), player.getY())){
    		lastMovements.insertLast(new MoveClass(MoveOutput.OFF_MAP));
    	} else if (!canMove(player.getX(), player.getY(), direction)){
    		lastMovements.insertLast(new MoveClass(MoveOutput.CANNOT_MOVE));
    	} else if(player.isAlive()){
    		result = true;
    	}	
    	return result;	
    }
    
    /**
     * Checks if the move command is possible on a given position and number of moves
     * @param x The horizontal position
     * @param y The vertical position
     * @param moves The number of moves
     * @return <code>true</code> if movement is possible. Otherwise, <code>false</code>.
     */
    private boolean checkGenericMoveConditions(int x, int y, int moves) {
    	boolean result = false; 
    	if (!isInside(x, y)) {
             lastMovements.insertLast(new MoveClass(MoveOutput.INVALID_POSITION));
         } else if (!isPlayer(x, y)) {
             lastMovements.insertLast(new MoveClass(MoveOutput.NO_PLAYER));
         } else if (!isValidMovement(x, y, moves)){
             lastMovements.insertLast(new MoveClass(MoveOutput.INVALID_MOVE));
         } else {
        	 result = true;
         }
    	return result;
    }

    /**
    * Moves the player and calls processMove to check following implications. Checks and eliminates teams if it is the case.
    * @param player The player who is about to move
    * @param dir The direction we want to move
    * @param x The horizontal position
    * @param y The vertical Position
    * @return a Move object with all the information regarding the movement
    */
    private Move movePlayer(Player player, String dir, int x, int y){
       Move newPos = player.move(dir);
       Move move = processMove(newPos,x,y);
       eliminateTeam();
       return move;
    }
    
    /**
     * Process the move command, processing fights and seizing bunkers.
     * @param newPos The move object with the information about the player movement to a new position
     * @param x The pre-movement horizontal position
     * @param y The pre-movement vertical position
     * @return a Move object with all the information regarding the movement
     */
    private Move processMove(Move newPos, int x, int y) {
    	Player player = newPos.getPlayer();
    	MapElement currentCell = map.getElement(x, y);
        MapElement nextCell = map.getElement(newPos.getX(), newPos.getY());   	
        Move result;
    	if(nextCell instanceof EmptyElementClass) {
    		result = moveToEmptyCell(player,newPos.getX(),newPos.getY());
    	}else if (nextCell instanceof Bunker){
    		Bunker bunker = findBunker(nextCell.getX(),nextCell.getY());
    		if(player.getTeam().equals(bunker.getTeam())){
    			result = moveToFreeBunker(player, bunker);
    		}else if(bunker.isFree()) {
    			result = seizeFreeBunker(player, bunker);
    		}else if(player.attack(bunker.getPlayer())){
    			result = this.winAndSeizeBunker(player, bunker);
    		}else {
    			result = this.lostFight(player);
    		}	
    	}else {
    		Player otherPlayer = findPlayer(nextCell.getX(),nextCell.getY(),nextCell.getTeam());
    		if(player.attack(otherPlayer)) {
    			result = this.wonFight(player, otherPlayer);
    		}else
    			result = this.lostFight(player);
    	}
    	updateMap(currentCell,x,y);
    	return result;
    }
    
    /**
     * Processes the movement when the player wins a fight.
     * @param player The player who is attacking
     * @param otherPlayer The player who is being attacked
     * @return a Move object with all the information regarding the movement
     */
    private Move wonFight(Player player, Player otherPlayer) {
    	otherPlayer.getTeam().removePlayer(otherPlayer);
    	map.addElement(player, otherPlayer.getX(), otherPlayer.getY());
    	return new MoveClass(player, MoveOutput.WON_FIGHT);
    }

    /**
     * Processes the movement when the player loses a fight.
     * @param player The player who is attacking
     * @return a Move object with all the information regarding the movement
     */
    private Move lostFight(Player player) {
    	currentTeam.removePlayer(player);
    	return new MoveClass(player, MoveOutput.PLAYER_ELIMINATED);
    }
    
    /**
     * Processes the movement when the player wins a fight and seizes a bunker.
     * @param player The player attacking
     * @param bunker The bunker being seized
     * @return a Move object with all the information regarding the movement
     */
    private Move winAndSeizeBunker(Player player,Bunker bunker) {
    	bunker.getTeam().removePlayer(bunker.getPlayer());
    	conquerBunker(player,bunker,true);
    	return new MoveClass(player, MoveOutput.WON_FIGHT_AND_BUNKER_SEIZED);
    }
    
    /**
     * Processes the movement when the player seizes a free bunker.
     * @param player The player who is moving to the bunker
     * @param bunker The bunker being seized
     * @return a Move object with all the information regarding the movement
     */
    private Move seizeFreeBunker(Player player, Bunker bunker) {
    	conquerBunker(player,bunker,true);
    	return new MoveClass(player, MoveOutput.BUNKER_SEIZED);	
    }
    
    /**
     * Conquers a bunker, changing the owner to the team of the player who is seizing it.
     * @param player The player who is conquering the bunker
     * @param bunker The bunker being conquered
     * @param isInvasion A boolean. True if the player invades the bunker. Otherwise, false
     */
    private void conquerBunker(Player player, Bunker bunker, boolean isInvasion) {
    	if(!bunker.isAbandoned()) {
    		bunker.getTeam().removeBunker(bunker);}
    	currentTeam.conquerBunker(bunker);
    	bunker.changeTeam(currentTeam);
    	if(isInvasion) {
    		bunker.playerIn(player);
    	} 	
    }
    
    /**
     * Moves the player who is moving to a free bunker.
     * @param player The player who is moving
     * @param bunker The bunker in which the player is entering
     * @return a Move object with all the information regarding the movement
     */
    private Move moveToFreeBunker(Player player, Bunker bunker) {
    	bunker.playerIn(player);
        return new MoveClass(player, MoveOutput.SUCCESS);
    }
            
    /**
     * Moves the player to an empty cell on the map.
     * @param player The player who is moving
     * @param newX The new horizontal position
     * @param newY The new vertical position
     * @return a Move object with all the information regarding the movement
     */        
    private Move moveToEmptyCell(Player player,int newX, int newY) {
    	map.addElement(player, newX, newY);
		return new MoveClass(player, MoveOutput.SUCCESS);
    }
    
    /**
     * Updates the map after a movement.
     * @param element The cell of the map to be updated
     * @param x the horizontal position
     * @param y the vertical position
     */
    private void updateMap(MapElement element, int x, int y) {
        if (element instanceof Player){
            map.removeElement(x, y);
        } else if (element instanceof Bunker){
            Bunker b = findBunker(element.getX(),element.getY());
            b.playerOut();
        }
    }
    
    @Override
    public boolean attack() {
    	Iterator<Player> playersIte = currentTeam.playerIterator();
    	while (playersIte.hasNext() && !isGameOver()){
    		Player player = playersIte.next();
    		boolean isPlayerAlive = true;
    		Iterator<Coords> coordsIte = player.attackPattern(map.getHeight(), map.getWidth()).iterator();
    		while (coordsIte.hasNext() && !isGameOver() && isPlayerAlive){
    			Coords attackCoords = coordsIte.next();
    			MapElement cell = map.getElement(attackCoords.getX(), attackCoords.getY());
    			if (cell instanceof Player && !player.getTeam().equals(cell.getTeam())){
    				Player otherPlayer = findPlayer(cell.getX(),cell.getY(),cell.getTeam());
    				isPlayerAlive = this.attackOtherPlayer(player,otherPlayer);
    			}else if(cell instanceof Bunker && !player.getTeam().equals(cell.getTeam())) {
    				Bunker bunker = findBunker(cell.getX(),cell.getY());
    				if(!bunker.isFree()) {
    					isPlayerAlive = attackBunker(player,bunker);
    				}else {
    					conquerBunker(player,bunker,false);
    				} 
    			}
    		}
    	}
    	eliminateTeam();
    	return currentTeam.isActive();
    }

    /**
     * Attacks a player inside a given bunker.
     * @param player the player who is attacking the player inside the bunker
     * @param bunker the bunker being attacked
     * @return <code>true</code> if the attack was successfull and the bunker seized. Otherwise, <code>false</code>.
     */
    private boolean attackBunker(Player player, Bunker bunker) {
    	boolean result = true;
    	if(attackOtherPlayer(player, bunker.getPlayer())) {
    		bunker.getTeam().removeBunker(bunker);
    		bunker.playerOut();
    		bunker.changeTeam(currentTeam);
    		currentTeam.conquerBunker(bunker);
    	}else {
    		result = false;
    	}
    	return result;
    }

    /**
     * Attacks another player.
     * @param player the player attacking
     * @param otherPlayer the player being attacked
     * @return <code>true</code> if the attack was sucessfull and the attacker won. Otherwise, <code>false</code>.
     */
    private boolean attackOtherPlayer(Player player, Player otherPlayer) {
    	boolean result = true;
    	if(player.attack(otherPlayer)) {
    		otherPlayer.getTeam().removePlayer(otherPlayer);
    		if(!isPlayerInsideBunker(otherPlayer)) {
    			map.removeElement(otherPlayer.getX(), otherPlayer.getY());	
    		}			
    	}else if(isPlayerInsideBunker(player)) {
    		findBunker(player.getX(),player.getY()).playerOut();
    		currentTeam.removePlayer(player);
    		result = false;
    	}else {
    		currentTeam.removePlayer(player);
    		map.removeElement(player.getX(), player.getY());
    		result = false;
    	}
    	return result;
    }
    
    /**
     * Eliminates all not active teams.
     */
    private void eliminateTeam() {
    	Iterator<Team> ite = teams.iterator();
    	Team[] team = new Team[teams.size()];
    	int counter = 0;
    	while (ite.hasNext()) {
    		Team t = ite.next();
    		if(!t.isActive())
    			team[counter++] = t;
    	}
    	int i = 0;
    	while(i < counter)
    		teams.removeAt(teams.searchIndexOf(team[i++]));
    }

    @Override
    public boolean isGameOver() {
        boolean result = teams.size() < MINIMUM_TEAMS;
        if (result){
            winner = teams.get(0).getName();
            status = false;
        }
        return result;
    }

    @Override
    public String getWinner() {
        return winner;
    }

    /**
     * Checks if the movement is possible inside the map
     * @param dir The direction of movement we wish to check
     * @param x the horizontal position
     * @param y the vertical position
     * @return <code>true</code> if the direction is valid. Otherwise, <code>false</code>.
     */
    private boolean isMovementPossible(String dir, int x, int y){
        boolean result = switch(Directions.valueOf(dir)){
            case NORTH -> isInside(x, y-1);
            case SOUTH -> isInside(x, y+1);
            case EAST -> isInside(x+1, y);
            case WEST -> isInside(x-1, y);
        };
        return result;
    }

    /**
     * Checks if a given direction is valid
     * @param dir The direction of movement we wish to check
     * @return <code>true</code> if the direction is valid. Otherwise, <code>false</code>.
     */
    private boolean isValidDirection(String dir){
        boolean exists = true;
        try{
            Directions.valueOf(dir);
        }catch (IllegalArgumentException e) {
            exists = false;
        }
        return exists;
    }

    /**
     * Finds the player located in position x,y of a given team.
     * @param x the horizontal position
     * @param y the vertical position
     * @param team the team to which the player belongs to
     * @return a Player object
     */
    private Player findPlayer(int x, int y, Team team){
        Iterator<Player> ite = team.playerIterator();
        Player player = null;
        boolean found = false;
        while (ite.hasNext() && !found){
            Player p = ite.next();
            if (p.getX() == x && p.getY() == y){
                player = p;
                found = true;
            }
        }
        return player;
    }
    
    /**
     * Checks if this player is inside a bunker
     * @param player The player to check
     * @return <code>true</code> if the player is inside a bunker. Otherwise, <code>false</code>.
     */
    private boolean isPlayerInsideBunker(Player player) {
    	return findBunker(player.getX(),player.getY()) != null;
    }
    
    /**
     * Finds the player located in position x,y.
     * @param x the horizontal position
     * @param y the vertical position
     * @return a Bunker object
     */
    private Bunker findBunker(int x, int y) {
    	Iterator<Bunker> ite = bunkers.iterator();
        Bunker bunker = null;
        boolean found = false;
        while (ite.hasNext() && !found){
            Bunker b = ite.next();
            if (b.getX() == x && b.getY() == y){
                bunker = b;
                found = true;
            }
        }
        return bunker;
    }

    /**
     * Checks if the movement command is valid on the player occupying the coordinates (x,y).
     * @param x the horizontal position
     * @param y the vertical position
     * @param nrMoves the number of movements to be made
     * @return <code>true</code> if the movement is valid. Otherwise, <code>false</code>.
     */
	private boolean isValidMovement(int x, int y, int nrMoves) {
		Player player = findPlayer(x, y, currentTeam);
		return player.getPossibleMoves() >= nrMoves;
	}

    /**
     * Checks if a given position is occupied by a player.
     * @param x The horizontal position
     * @param y The vertical position
     * @return <code>true</code> if the position is occupied by a player. Otherwise, <code>false</code>.
     */
	private boolean isPlayer(int x, int y) {
		return findPlayer(x,y,currentTeam) != null;
	}

    /**
     * Checks if a player can move in a certain direction
     * @param x the horizontal position
     * @param y the vertical position
     * @param dir the direction of the movement
     * @return <code>true</code> if the player can move in that direction. Otherwise, <code>false</code>.
     */
	private boolean canMove(int x, int y, String dir) {
		return !map.nextCellOccupied(x, y, dir);
	}
}
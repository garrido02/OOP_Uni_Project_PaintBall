/**
 * @author Francisco Correia & Sérgio Garrido
 */

package PaintBall;
import DataStructures.Array;
import DataStructures.ArrayClass;

/**
 * Class BluePlayer which extends the PlayerAbstract Class.
 */
public class BluePlayerClass extends PlayerAbstract {
	
	/**
	 * The type of player this class represents.
	 */
	public static final String TYPE = "BLUE";
	
	/**
	 * Default number of this player type possible moves.
	 */
	private static final int MAX_MOVES = 1;
	
	/**
	 * Default cost of this player type.
	 */
	private static final int COST = 2;
	
	/**
	 * Constructor
	 * @param x the horizontal position
	 * @param y the vertical position
	 * @param team the team to which the player belongs to
	 */
	public BluePlayerClass(int x, int y, Team team) {
		super(x, y, team);
		this.cost = COST;
		this.type = TYPE;
		this.possibleMoves = MAX_MOVES;
	}

	@Override
	public Array<Coords> attackPattern(int rows, int cols) {
		int i = this.getX();
		int nextX = this.getX();
		Array<Coords> pattern = new ArrayClass<>();
		int nrSteps = 1;
		while (i - nrSteps >= 0 || i + nrSteps < cols){
			if (i - nrSteps >= 0 ){
				nextX = i - nrSteps;
				pattern.insertLast(new CoordsClass(nextX, this.getY()));
			}
			if (i + nrSteps < cols){
				nextX = i + nrSteps;
				pattern.insertLast(new CoordsClass(nextX, this.getY()));
			}
			nrSteps++;
		}
		return pattern;
	}
}

/**
 * @author Francisco Correia & Sérgio Garrido
 */


package PaintBall;
import DataStructures.Array;


/**
 * Interface Player responsible for creating all the Player Class prototypes and extending the MapElement interface.
 */
public interface Player extends MapElement{

	/**
	 * Processes the movement of the player.
	 * @param dir the direction of the movement
	 * @return a Move object with all the information regarding the movement
	 * @pre dir != null
	 */
	Move move(String dir);

	/**
	 * Returns the creating cost of the player.
	 * @return the creating cost of the player
	 */
	int cost();

	/**
	 * Returns the type of the player.
	 * @return the type of the player.
	 */
	String getType();

	/**
	 * Checks if the attack was sucessfull.
	 * @param other the player being attacked
	 * @return <code>true</code> if the attacker won the fight. Otherwise, <code>false</code>.
	 * @pre other != null
	 */
	boolean attack(Player other);

	/**
	 * Returns the player's number of possible moves.
	 * @return the player's number of possible moves
	 */
	int getPossibleMoves();

	/**
	 * Returns the attack pattern of the player.
	 * @param rows the number of rows of the current map
	 * @param cols the number of columns of the current map
	 * @return an array of Coords objects representing where the player will attack.
	 */
	Array<Coords> attackPattern(int rows, int cols);

	/**
	 * Checks if the player is alive.
	 * @return <code>true</code> if the player is alive. Otheriwse, <code>false</code>.
	 */
	boolean isAlive();

	/**
	 * Eliminates the player.
	 */
	void eliminate();
	
}


package PaintBall;

public interface Coords {
    int getX();
    int getY();
}

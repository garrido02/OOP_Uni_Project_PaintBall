package PaintBall;

public enum Directions {
    NORTH, SOUTH, EAST, WEST
}

package PaintBall;

public enum PlayerType {
	RED, GREEN, BLUE
}
